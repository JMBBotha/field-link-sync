-- Assign admin role to the existing user
INSERT INTO public.user_roles (user_id, role)
VALUES ('420c7731-e8a4-4355-80ca-51c684b42a2c', 'admin');